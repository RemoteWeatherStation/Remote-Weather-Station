var dataArrayTemp = [];
var dataArrayHumid = [];
var dataArrayPress = [];
var dataArrayCO2 = [];
var dataArrayTVOC = [];


var defaultZoomTime = 24*60*60*1000; // 1 day
var minZoom = -6; // 22 minutes 30 seconds
var maxZoom = 8; // ~ 8.4 months

var zoomLevel = 0;
var viewportEndTime = new Date();
var viewportStartTime = new Date();

loadCSV(); // Download the CSV data, load Google Charts, parse the data, and draw the chart


/*
Structure:

    loadCSV
        callback:
        parseCSV
        load Google Charts (anonymous)
            callback:
            updateViewport
                displayDate
                drawChart
*/

/*
               |                    CHART                    |
               |                  VIEW PORT                  |
invisible      |                   visible                   |      invisible
---------------|---------------------------------------------|--------------->  time
       viewportStartTime                              viewportEndTime

               |______________viewportWidthTime______________|

viewportWidthTime = 1 day * 2^zoomLevel = viewportEndTime - viewportStartTime
*/

function loadCSV() {
    var xmlhttpTemp = new XMLHttpRequest();
    xmlhttpTemp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            dataArrayTemp = parseCSV(this.responseText);
            google.charts.load('current', { 'packages': ['line', 'corechart'] });
            google.charts.setOnLoadCallback(updateViewport);
        }
    };
    var xmlhttpHumid = new XMLHttpRequest();
    xmlhttpHumid.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            dataArrayHumid = parseCSV(this.responseText);
            google.charts.load('current', { 'packages': ['line', 'corechart'] });
            google.charts.setOnLoadCallback(updateViewport);
        }
	};
    var xmlhttpPress = new XMLHttpRequest();
    xmlhttpPress.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            dataArrayPress = parseCSV(this.responseText);
            google.charts.load('current', { 'packages': ['line', 'corechart'] });
            google.charts.setOnLoadCallback(updateViewport);
        }
	};
    var xmlhttpCO2 = new XMLHttpRequest();
    xmlhttpCO2.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            dataArrayCO2 = parseCSV(this.responseText);
            google.charts.load('current', { 'packages': ['line', 'corechart'] });
            google.charts.setOnLoadCallback(updateViewport);
        }
	};
    var xmlhttpTVOC = new XMLHttpRequest();
    xmlhttpTVOC.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            dataArrayTVOC = parseCSV(this.responseText);
            google.charts.load('current', { 'packages': ['line', 'corechart'] });
            google.charts.setOnLoadCallback(updateViewport);
        }
	};


    xmlhttpTemp.open("GET", "temp.csv", true);
    xmlhttpTemp.send();
    xmlhttpHumid.open("GET", "humid.csv", true);
    xmlhttpHumid.send();
    xmlhttpPress.open("GET", "press.csv", true);
    xmlhttpPress.send();
    xmlhttpCO2.open("GET", "co2.csv", true);
    xmlhttpCO2.send();
    xmlhttpTVOC.open("GET", "tvoc.csv", true);
    xmlhttpTVOC.send();
    var loadingdiv = document.getElementById("loading");
    loadingdiv.style.visibility = "visible";
}

function parseCSV(string) {
    var array = [];
    var lines = string.split("\n");
    for (var i = 0; i < lines.length; i++) {
        var data = lines[i].split(",", 2);
        data[0] = new Date(parseInt(data[0]) * 1000);
        data[1] = parseFloat(data[1]);
        array.push(data);
    }
    return array;
}

function drawChart() {
    var dataTemp = new google.visualization.DataTable();
    dataTemp.addColumn('datetime', 'UNIX');
    dataTemp.addColumn('number', 'Temperature');

    dataTemp.addRows(dataArrayTemp);

    var dataHumid = new google.visualization.DataTable();
    dataHumid.addColumn('datetime', 'UNIX');
    dataHumid.addColumn('number', 'Humidity');

    dataHumid.addRows(dataArrayHumid);

    var dataPress = new google.visualization.DataTable();
    dataPress.addColumn('datetime', 'UNIX');
    dataPress.addColumn('number', 'Pressure');

    dataPress.addRows(dataArrayPress);

    var dataCO2 = new google.visualization.DataTable();
    dataCO2.addColumn('datetime', 'UNIX');
    dataCO2.addColumn('number', 'CO2');

    dataCO2.addRows(dataArrayCO2);

    var dataTVOC = new google.visualization.DataTable();
    dataTVOC.addColumn('datetime', 'UNIX');
    dataTVOC.addColumn('number', 'TVOC');

    dataTVOC.addRows(dataArrayTVOC);


    var optionsTemp = {
        curveType: 'function',

        height: 360,

        legend: { position: 'none' },

        hAxis: {
            viewWindow: {
                min: viewportStartTime,
                max: viewportEndTime
            },
            gridlines: {
                count: -1,
                units: {
                    days: { format: ['MMM dd'] },
                    hours: { format: ['HH:mm', 'ha'] },
                }
            },
            minorGridlines: {
                units: {
                    hours: { format: ['hh:mm:ss a', 'ha'] },
                    minutes: { format: ['HH:mm a Z', ':mm'] }
                }
            }
        },
        vAxis: {
            title: "Temperature (Celsius)"
        }
    };
    var optionsHumid = {
        curveType: 'function',

        height: 360,

        legend: { position: 'none' },

        hAxis: {
            viewWindow: {
                min: viewportStartTime,
                max: viewportEndTime
            },
            gridlines: {
                count: -1,
                units: {
                    days: { format: ['MMM dd'] },
                    hours: { format: ['HH:mm', 'ha'] },
                }
            },
            minorGridlines: {
                units: {
                    hours: { format: ['hh:mm:ss a', 'ha'] },
                    minutes: { format: ['HH:mm a Z', ':mm'] }
                }
            }
        },
        vAxis: {
            title: "Humidity (%)"
        }
    };
    var optionsPress = {
        curveType: 'function',

        height: 360,

        legend: { position: 'none' },

        hAxis: {
            viewWindow: {
                min: viewportStartTime,
                max: viewportEndTime
            },
            gridlines: {
                count: -1,
                units: {
                    days: { format: ['MMM dd'] },
                    hours: { format: ['HH:mm', 'ha'] },
                }
            },
            minorGridlines: {
                units: {
                    hours: { format: ['hh:mm:ss a', 'ha'] },
                    minutes: { format: ['HH:mm a Z', ':mm'] }
                }
            }
        },
        vAxis: {
            title: "Pressure (Pa)"
        }
    };

    var optionsCO2 = {
        curveType: 'function',

        height: 360,

        legend: { position: 'none' },

        hAxis: {
            viewWindow: {
                min: viewportStartTime,
                max: viewportEndTime
            },
            gridlines: {
                count: -1,
                units: {
                    days: { format: ['MMM dd'] },
                    hours: { format: ['HH:mm', 'ha'] },
                }
            },
            minorGridlines: {
                units: {
                    hours: { format: ['hh:mm:ss a', 'ha'] },
                    minutes: { format: ['HH:mm a Z', ':mm'] }
                }
            }
        },
        vAxis: {
            title: "CO2 (ppm)"
        }
    };
    var optionsTVOC = {
        curveType: 'function',

        height: 360,

        legend: { position: 'none' },

        hAxis: {
            viewWindow: {
                min: viewportStartTime,
                max: viewportEndTime
            },
            gridlines: {
                count: -1,
                units: {
                    days: { format: ['MMM dd'] },
                    hours: { format: ['HH:mm', 'ha'] },
                }
            },
            minorGridlines: {
                units: {
                    hours: { format: ['hh:mm:ss a', 'ha'] },
                    minutes: { format: ['HH:mm a Z', ':mm'] }
                }
            }
        },
        vAxis: {
            title: "TVOC (ppb)"
        }
    };

    var chartTemp = new google.visualization.LineChart(document.getElementById('chart_divTemp'));
    var chartHumid = new google.visualization.LineChart(document.getElementById('chart_divHumid'));
    var chartPress = new google.visualization.LineChart(document.getElementById('chart_divPress'));
    var chartCO2 = new google.visualization.LineChart(document.getElementById('chart_divCO2'));
    var chartTVOC = new google.visualization.LineChart(document.getElementById('chart_divTVOC'));
		
    chartTemp.draw(dataTemp, optionsTemp);
    chartHumid.draw(dataHumid, optionsHumid);
    chartPress.draw(dataPress, optionsPress);
    chartCO2.draw(dataCO2, optionsCO2);
    chartTVOC.draw(dataTVOC, optionsTVOC);

    var dateselectdiv = document.getElementById("dateselect");
    dateselectdiv.style.visibility = "visible";

    var loadingdiv = document.getElementById("loading");
    loadingdiv.style.visibility = "hidden";
}

function displayDate() { // Display the start and end date on the page
    var dateDiv = document.getElementById("date");

    var endDay = viewportEndTime.getDate();
    var endMonth = viewportEndTime.getMonth();
    var startDay = viewportStartTime.getDate();
    var startMonth = viewportStartTime.getMonth()
    if (endDay == startDay && endMonth == startMonth) {
        dateDiv.textContent = (endDay).toString() + "/" + (endMonth + 1).toString();
    } else {
        dateDiv.textContent = (startDay).toString() + "/" + (startMonth + 1).toString() + " - " + (endDay).toString() + "/" + (endMonth + 1).toString();
    }
}

document.getElementById("prev").onclick = function() {
    viewportEndTime = new Date(viewportEndTime.getTime() - getViewportWidthTime()/3); // move the viewport to the left for one third of its width (e.g. if the viewport width is 3 days, move one day back in time)
    updateViewport();
}
document.getElementById("next").onclick = function() {
    viewportEndTime = new Date(viewportEndTime.getTime() + getViewportWidthTime()/3); // move the viewport to the right for one third of its width (e.g. if the viewport width is 3 days, move one day into the future)
    updateViewport();
}

document.getElementById("zoomout").onclick = function() {
    zoomLevel += 1; // increment the zoom level (zoom out)
    if(zoomLevel > maxZoom) zoomLevel = maxZoom;
    else updateViewport();
}
document.getElementById("zoomin").onclick = function() {
    zoomLevel -= 1; // decrement the zoom level (zoom in)
    if(zoomLevel < minZoom) zoomLevel = minZoom;
    else updateViewport();
}

document.getElementById("reset").onclick = function() {
    viewportEndTime = new Date(); // the end time of the viewport is the current time
    zoomLevel = 0; // reset the zoom level to the default (one day)
    updateViewport();
}
document.getElementById("refresh").onclick = function() {
    viewportEndTime = new Date(); // the end time of the viewport is the current time
    loadCSV(); // download the latest data and re-draw the chart
}

document.body.onresize = drawChart;

function updateViewport() {
    viewportStartTime = new Date(viewportEndTime.getTime() - getViewportWidthTime());
    displayDate();
    drawChart();
}
function getViewportWidthTime() {
    return defaultZoomTime*(2**zoomLevel); // exponential relation between zoom level and zoom time span
                                           // every time you zoom, you double or halve the time scale
}

